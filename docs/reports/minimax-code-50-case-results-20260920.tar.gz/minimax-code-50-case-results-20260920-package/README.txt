Sanitized ABB MiniMax Code batch evidence. Raw traces and SDK payloads remain outside this package by design.
